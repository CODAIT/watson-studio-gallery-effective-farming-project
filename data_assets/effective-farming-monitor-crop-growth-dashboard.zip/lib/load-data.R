# Sample Materials, provided under license.
# Licensed Materials - Property of IBM
# © Copyright IBM Corp. 2019. All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

# Load Data from CSV files

library(readr)
library(scales)

readDataset <- function(fileName) {read.csv(file.path("datasets", fileName)) }

weather <- readDataset("jfk_weather_cleaned.csv")


clients <- list(
  list(name="Monitor Climate", image="NY.jpg")
)
clientIds <- c(1)
names(clients) <- clientIds