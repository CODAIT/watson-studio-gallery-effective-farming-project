# Sample Materials, provided under license.
# Licensed Materials - Property of IBM
# © Copyright IBM Corp. 2019. All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.


clientButton <- function(id, name, image) {
  tags$p(
    actionButton(paste0('client-btn-', id),
                 fluidRow(
                   column(3, 
                          tags$img(src = image, width = "100px", height = "100px")
                   ),
                   column(1,
                          tags$h3(name)
                   )
                 ),
                 style="width:100%"
    )
  )
}

homePanel <- function() {
  
  tabPanel(
    "Crop Guide",
    tags$head(
      tags$style(HTML("
        .datatables {
          width: 100% !important;
        }
      "))
    ),
    shinyjs::useShinyjs(),

    fluidRow(
      column(2,
             h3("Weather History"),
             h4("Area - Queens, NY, USA"),
             h5("Click on the marker to know 30-day average"),
             leafletOutput('map'),
             tags$br()),
      column(5,
             h3("Crop Guide - Onion"),
             plotlyOutput('details_pt'),
             #tableOutput('tbl'),
             #tableOutput('disease')
             ),
      column(5,
             h3("Past 30-Days Weather"),
             plotlyOutput('daily_weather')
      ),
    )

   )
  
 
}


# Weather data


readDataset <- function(fileName) {read.csv(file.path("datasets", fileName)) }

weather <- readDataset("jfk_weather_cleaned.csv")

# weather_selected = tail(weather, n = 720)
weather_selected = weather[73681:74400, ]

mean_temp = mean(weather_selected$HOURLYDRYBULBTEMPF)
mean_humidity =  mean(weather_selected$HOURLYRelativeHumidity)
mean_wind = mean(weather_selected$HOURLYWindSpeed)
mean_precip = mean(weather_selected$HOURLYPrecip)


daily_temp <- plot_ly(data=weather_selected, x=weather_selected$DATE, y=weather_selected$HOURLYDRYBULBTEMPF, 
                      type='scatter', mode='lines', width=680, height=800, name = "Temperature", 
                      legendgroup = "Temperature")

daily_humidity <- plot_ly(data=weather_selected, x=weather_selected$DATE, y=weather_selected$HOURLYRelativeHumidity, type='scatter', mode='lines', width=680, height=800, name = "Humidity", legendgroup = "Humidity")

daily_wind <- plot_ly(data=weather_selected, x=weather_selected$DATE, y=weather_selected$HOURLYWindSpeed, type='scatter', mode='lines', width=680, height=800, name = "Wind Speed", legendgroup = "Wind Speed")

daily_precip <- plot_ly(data=weather_selected, x=weather_selected$DATE, y=weather_selected$HOURLYPrecip, type='scatter', mode='lines', width=680, height=800, name = "Precipitation", legendgroup = "Precipitation")

#daily_weather <- subplot(daily_temp, daily_humididty, nrows=2, margin=0.04, heights = c(0.5, 0.5), shareX = TRUE, titleY=TRUE)
#p1 <- add_lines(daily_temp, color = I("black"), name = "1st", legendgroup = "1st")
#p2 <- add_lines(daily_humididty, color = I("red"), name = "2nd", legendgroup = "2nd")

daily_weather <- subplot(
  daily_temp,
  daily_humidity,
  daily_wind,
  daily_precip,
  nrows = 4, margin = 0.05, shareX = TRUE
)

details <- data.frame(Crop = c('Stages','Preferred Climate', 'Daily Temperature', 'Critical Day Length', 
                              'Soil Texture', 'Optimum pH', 'Fertilizer'
                             ), 
                      Onion = c('Establishment, Vegetative Growth, Bulb Initiation, Bulb Development, Maturation', 
                                'Mild - no extreme temperature and no excessive rainfall', 
                                '59 - 68 Degree Fahrenheit',
                                '11 to 16 hours', 'Medium', '6 to 7', 
                                '60 to 100 kg/ha N, 25 to 45 kg/ha P and 45 to 80 kg/ha K'
                                ))

values <- rbind (c('Stages','Preferred Climate', 'Daily Temperature', 'Critical Day Length', 
                   'Soil Texture', 'Optimum pH', 'Fertilizer', 
                   'Fungal Disease<br>Development Conditions',
                   'Bacterial Disease<br>Development Conditions',
                   'Fungicide Evaporation<br>Temperature'),
                 c('Establishment<br>Vegetative Growth<br>Bulb Initiation<br>Bulb Development<br>Maturation', 
                   'Mild - no extreme temperature and no excessive rainfall', 
                   '59 - 68 Degree Fahrenheit',
                   '11 to 16 hours', 'Medium', '6 to 7', 
                   '60 to 100 kg/ha N, <br>25 to 45 kg/ha P <br>45 to 80 kg/ha K',
                   '<b>Black Mold</b><br>Temperature = 86°F<br><b>Botrytis Leaf Blight</b><br>High humidity & warm temperature<br><b>Downy Mildew</b><br>Humidity > 95%<br><b>Fusarium Basal Plate Rot</b><br>Temperature = 80°F<br><b>Pink Root</b><br>Temperature between 75 - 82°F',
                   '<b>Bacterial Soft Rot</b><br>Temperature range of 68-86°F<br><b>Bulb Decay</b><br>Temperature range of 104-113°F<br><b>Sour Skin</b><br>Temperature > 86°F',
                   '75 Degree Fahrenheit'
                 ))
disease <- data.frame(Disease = c('Black Mold', 'Botrytis Leaf Blight', 'Downy Mildew', 'Fusarium Basal Plate Rot',
                                  'Pink Root', 'Bacterial Soft Rot', 'Enterobacter Bulb Decay', 'Sour Skin'))
details_pt <- plot_ly(
  type = 'table',
  header = list(
    values = c('Factors', 'Guide'),
    line = list(color = '#000000'),
    fill = list(color = '#FFA500'),
    align = c('center'),
    font = list(color = '#000000', size = 18),
    height = 35
  ),
  cells = list(
    values = values,
    line = list(color = '#506784'),
    fill = list(color = c('#FFEFD5',
                          'white')),
    align = c('left'),
    font = list(color = c('#161616'), size = 13),
    height = 40
  ), height=850) 

content <- paste(sep = "<br/>",
                 "<b>30-Day Average</b>", "<br>",
                 "Temperature:", mean_temp, "<br>",
                 "Humidity: ", mean_humidity, "<br>",
                 "Wind Speed", mean_wind, "<br>",
                 "Precipitation", mean_precip)


homeServer <- function(input, output, session, sessionVars) {
  
  # Observation events for client buttons
  lapply(paste0('client-btn-', clientIds),
         function(x){
           observeEvent(
             input[[x]],
             {
               id <- as.numeric(sub("client-btn-", "", x))
               sessionVars$selectedClientId <- id
               updateTabsetPanel(session, "lfeNav", selected = "clientPanel")
             }
           )
         })
  
  # Display plot
  
  output$daily_temp <- renderPlotly(daily_temp)
  
  output$daily_weather <- renderPlotly(daily_weather)
  
  output$details_pt <- renderPlotly(details_pt)
  
  # output$tbl <- renderTable(details,  
  #                           striped = TRUE,  
  #                          hover = TRUE, width='100%')
  # output$disease <- renderTable(disease,  
  #                           striped = TRUE,  
  #                           hover = TRUE, width='100%')
  
  output$map<- renderLeaflet({
    
    leaflet() %>%
      addTiles() %>%  # Add default OpenStreetMap map tiles
      #addMarkers(lng=-73.769417,lat=40.742054)
      addMarkers(-73.769417, 40.742054, popup = content)
  })
  
}
