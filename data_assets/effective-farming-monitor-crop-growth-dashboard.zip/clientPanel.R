# Sample Materials, provided under license.
# Licensed Materials - Property of IBM
# © Copyright IBM Corp. 2019. All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

# Load shap JavaScript
# shapjs <- content(GET("https://github.com/slundberg/shap/raw/0849aa20551cf9825f9e294fcc29d7fbe7b9f932/shap/plots/resources/bundle.js"))

clientPanel <- function() {
  
  tabPanel(
    "Weather Status",
    value = "clientPanel",
    
    fluidPage(
      h3("Weather Prediction - Next 5 Hours"),
      br(),
      
      tags$div(
        id = "authPanel",
        column(5,
          panel(
            h4("Connect to Cloud Pak for Data API"),
            br(),
            textInput("hostname", "ICP4D Hostname"),
            textInput("username", "ICP4D Username"),
            passwordInput("password", "ICP4D Password"),
            actionButton("authBtn", "Authenticate API", class = "btn-primary btn-lg btn-block", style = "max-width:300px", disabled = TRUE),
            tags$head(tags$style("#authError{color:red;}")),
            verbatimTextOutput("authError")
          ),
         style = "max-width:500px;"
        )
      ),
      hidden(
        tags$div(
          id = "deploymentPanel",
          column(4,
             panel(
               tags$h4("Model Scoring Pipeline Deployment"),
               br(),
               pickerInput(
                 inputId = 'deploymentSelector',
                 label = 'Deployment:',
                 choices = list(),
                 options = pickerOptions(width = "auto", style = "btn-primary")
               ),
               tags$p(
                 tags$strong("Space Name: "),
                 textOutput(outputId = "space_name", inline = TRUE)
               ),
               tags$p(
                 tags$strong("GUID: "),
                 textOutput(outputId = "deployment_guid", inline = TRUE)
               ),
               tags$p(
                 tags$strong("Tags: "),
                 textOutput(outputId = "deployment_tags", inline = TRUE),
                 style = "word-wrap: break-word"
               ),
               tags$p(
                 tags$strong("Scoring Endpoint: "),
                 textOutput(outputId = "scoring_url", inline = TRUE),
                 style = "word-wrap: break-word"
               ),
             )
          ),
         
          tags$div(id = "scoreBtnSection",
            column(5,
              br(),br(),
              p('Predictions and Alerts are provided as per the Crop Guide.', style = "font-size:20px; text-align: center;"),
              br(),
              br(),
              actionButton(
                "scoreBtn",
                "Click to run forecast",
                class = "btn-primary btn-lg btn-block",
                disabled = TRUE
              ),
              textOutput("Predictions")%>% withSpinner(size=3),
              br(),
              tags$head(tags$style("#scoringError{color:red;}")),
              verbatimTextOutput("scoringError"),
              br())
          ),
          column(7,
             hidden(
               tags$div(id = "scoringResponse")
             )
          )
        )
      )
    )
  )
}

# Reactive server variables store (pervades across all sessions)
serverVariables = reactiveValues(deployments = list(), token = '')

if(nchar(Sys.getenv('CP4D_HOSTNAME')) > 0 && nchar(Sys.getenv('CP4D_USERNAME')) > 0 && nchar(Sys.getenv('CP4D_PASSWORD')) > 0) {
  tryCatch({
    deploymentsResp = collectDeployments(Sys.getenv('CP4D_HOSTNAME'), Sys.getenv('CP4D_USERNAME'), Sys.getenv('CP4D_PASSWORD'), "complete_forecast_function_deployment_tag")
    serverVariables$deployments <- deploymentsResp$deployments
    serverVariables$token = deploymentsResp$token
  }, warning = function(w) {
    print(w$message)
  }, error = function(e) {
    print(e$message)
  })
}

clientServer <- function(input, output, session, sessionVars) {
  
  observe({

    client <- clients[[toString(sessionVars$selectedClientId)]]

    # Update client name & image
    output$customerName <- renderText(client$name)
    removeUI(selector = "#customerImage > *")
    insertUI(
      selector = "#customerImage",
      where = "beforeEnd",
      ui = img(src = paste0("profiles/",client$image), style = "display: block;margin-left: auto;margin-right: auto;", width=150, height=150)
    )
    
    # Load customer data for customer sessionVars$selectedClientId
    selection <- tail(weather$HOURLYDRYBULBTEMPF, n=1)
      
  
    output$customerInfo <- renderUI({
      tags$ul( class = 'list-unstyled',
               tags$li(
                 tags$strong('Current Temperature: '), tags$span(class = "pull-right", selection, ' Degree Fahrenheit')
               )
      )
    })
    
    # Reset scoring
    removeUI(selector = "#scoringResponse > *", multiple = TRUE)
    shinyjs::hide(id = "scoringResponse")
    shinyjs::show(id = "scoreBtnSection")
    output$scoringError <- renderText('')
    sessionVars$pipelineInput <- list('values' = list('test_data' = as.integer(0)))
    output$pipelineInput <- renderText(toJSON(sessionVars$pipelineInput, indent = 2))
  })

  
  # Set default hostname for ICP4D API
  observeEvent(session$clientData$url_hostname, {
     updateTextInput(session, "hostname", value = session$clientData$url_hostname)
   })
  
  # Enable buttons when inputs are provided
  observe({
    toggleState("authBtn", nchar(input$hostname) > 0 && nchar(input$username) > 0 && nchar(input$password) > 0)
    toggleState("scoreBtn", nchar(input$endpoint) > 0 && nchar(input$token) > 0 && length(input$allCustomers_rows_selected) > 0)
  })
  
  # Handle ICP4D API authentication button
  observeEvent(input$authBtn, {
    shinyjs::disable("authBtn")
    
    tryCatch({
      deploymentsResp = collectDeployments(input$hostname, input$username, input$password, "complete_forecast_function_deployment_tag")
      serverVariables$deployments <- deploymentsResp$deployments
      serverVariables$token = deploymentsResp$token
    }, warning = function(w) {
      output$authError <- renderText(w$message)
    }, error = function(e) {
      output$authError <- renderText(e$message)
    })
    
    shinyjs::enable("authBtn")
  })
  
  observe({
    if(length(serverVariables$deployments) > 0) {
      updateSelectInput(session, "deploymentSelector", choices = names(serverVariables$deployments))
      shinyjs::hide(id = "authPanel")
      shinyjs::show(id = "deploymentPanel")
    }
  })
  
  
  
  # Handle model deployment dropdown switching
  observeEvent(input$deploymentSelector, {
    selectedDeployment <- serverVariables$deployments[[input$deploymentSelector]]
    output$deployment_guid <- renderText(selectedDeployment$guid)
    output$space_name <- renderText(selectedDeployment$space_name)
    output$deployment_tags <- renderText(selectedDeployment$tags)
    output$scoring_url <- renderText(selectedDeployment$scoring_url)
    toggleState("scoreBtn", nchar(selectedDeployment$scoring_url) > 0 && nchar(serverVariables$token) > 0)
  })
  
  
  
  
  
  # Handle model deployment scoring button
  observeEvent(input$scoreBtn, {
    shinyjs::disable("scoreBtn")
    
    selectedDeployment <- serverVariables$deployments[[input$deploymentSelector]]
    
    payload = list(
      values = list(test_data = 0)
    )
    
    response <- scoreModelDeployment(selectedDeployment$scoring_url, payload, serverVariables$token)
  
    if(length(response$error) > 0) {
      output$scoringError <- renderText(toString(response$error))
    }
    else if(length(response$predictions) > 0) {
      shinyjs::hide(id = "scoreBtnSection")
      shinyjs::show(id = "scoringResponse")
      
      print(input$mail)
      print(input$password_g)
      
      temp_values <- c()
      humidity_values <- c()
      precip_values <- c()
      ws_values <- c()
      date_values <- c()
      # Warning
      t_warn <- c('Temperature Alert',' ', ' ', ' ', ' ', ' ')
      s_cell <- c('SolarPanel Alert ',' ', ' ', ' ', ' ', ' ')
      fung_warn <- c('Fungicide Evaporation',' ', ' ', ' ', ' ', ' ')
      f1 <- c('Black Mold',' ', ' ', ' ', ' ', ' ')
      f2 <- c('Botrytis Leaf Blight',' ', ' ', ' ', ' ', ' ')
      f3 <- c('Downy Mildew',' ', ' ', ' ', ' ', ' ')
      f4 <- c('Fusarium Basal Plate Rot',' ', ' ', ' ', ' ', ' ')
      f5 <- c('Pink Root',' ', ' ', ' ', ' ', ' ')
      #
      b1 <- c('Bacterial Soft Rot',' ', ' ', ' ', ' ', ' ')
      b2 <- c('Enterobacter Bulb Decay',' ', ' ', ' ', ' ', ' ')
      b3 <- c('Sour Skin',' ', ' ', ' ', ' ', ' ')
      #
      alert_date <- c('DateTime',' ', ' ', ' ', ' ', ' ')
      
    
      
      for (i in 1:5)
        temp_values[i] <- response$predictions[[1]]$values[[1]][[i]]
      
      for (i in 1:5)
        humidity_values[i] <- response$predictions[[1]]$values[[1]][[i+5]]
      
      for (i in 1:5)
        ws_values[i] <- response$predictions[[1]]$values[[1]][[i+10]]
      
      for (i in 1:5)
        precip_values[i] <- response$predictions[[1]]$values[[1]][[i+15]]
      
      for (i in 1:5)
        date_values[i] <- response$predictions[[1]]$time[[1]][[i]]
      
      ##### Alert
      
      for (i in 2:6)
        alert_date[i] <- response$predictions[[1]]$time[[1]][[i-1]]
      
      for (i in 2:6)
        if ((response$predictions[[1]]$values[[1]][[i-1]] > 68) && (response$predictions[[1]]$values[[1]][[i-1]] < 70))
        {
          t_warn[i] <- 'Medium'
        } 
      
      for (i in 2:6)
        if (response$predictions[[1]]$values[[1]][[i-1]] > 70)
        {
          t_warn[i] <- 'High'
          s_cell[i] <- 'Turn On'
        }
      
      for (i in 2:6)
        if (response$predictions[[1]]$values[[1]][[i-1]] > 75)
        {
          fung_warn[i] <- 'High'
        }
      
      for (i in 2:6)
        if (response$predictions[[1]]$values[[1]][[i-1]] == 86)
        {
          f1[i] <- 'High'
        }
      
      for (i in 2:6)
        if ((response$predictions[[1]]$values[[1]][[i-1]] > 70) && (humidity_values[i-1] > 95))
        {
          f2[i] <- 'High'
        }
      
      for (i in 2:6)
        if (humidity_values[i-1] > 95)
        {
          f3[i] <- 'High'
        }
      
      for (i in 2:6)
        if (response$predictions[[1]]$values[[1]][[i-1]] == 80)
        {
          f4[i] <- 'High'
        }
      
      for (i in 2:6)
        if ((response$predictions[[1]]$values[[1]][[i-1]] > 75) && (response$predictions[[1]]$values[[1]][[i-1]] < 82))
        {
          f5[i] <- 'High'
        }
      
      for (i in 2:6)
        if ((response$predictions[[1]]$values[[1]][[i-1]] > 68) && (response$predictions[[1]]$values[[1]][[i-1]] < 86))
        {
          b1[i] <- 'High'
        }
      
      for (i in 2:6)
        if ((response$predictions[[1]]$values[[1]][[i-1]] > 104) && (response$predictions[[1]]$values[[1]][[i-1]] < 113))
        {
          b2[i] <- 'High'
        }
      
      for (i in 2:6)
        if (response$predictions[[1]]$values[[1]][[i-1]] > 86)
        {
          b3[i] <- 'High'
        }
      
      ####
      
      
  
      
      print(date_values)
      print(temp_values)
      print(humidity_values)
      print(ws_values)
      print(precip_values)
      
      # Temp vs Humidity
      temp_hum <- list(temp_values, humidity_values)
      col_names_comb <- c('Temperature', 'Humidity')
      df_comb <- do.call(data.frame,temp_hum)
      colnames(df_comb) <- col_names_comb
      df_comb <- data.frame(df_comb)
      
      # Final Prediction
      final_col <- list(date_values, temp_values, humidity_values, precip_values, ws_values)
      col_names <- c('DateTime', 'Temperature', 'Humidity','Precipitation', 'WindSpeed')
      df_pred <- do.call(data.frame,final_col)
      colnames(df_pred) <- col_names
      df_pred <- data.frame(df_pred)
     
      
      # Final Alert
      final_alert <- list(t_warn, s_cell, fung_warn, f1, f2, f3, f4, f5, b1, b2, b3)
      col_names <- c('Temperature', 'SolarPanel', 'Fungicide', 'Black Mold', 'Botrytis Leaf Blight',
                     'Downy Mildew', 'Fusarium Basal Plate Rot', 'Pink Root', 'Bacterial Soft Rot', 
                     'Enterobacter Bulb Decay', 'Sour Skin')
      df_alert <- do.call(data.frame,final_alert)
      colnames(df_alert) <- col_names
      df_alert <- data.frame(df_alert)
      df_alert <- as.data.frame(t(as.matrix(df_alert)))
      
      result <- response$predictions[[1]]$values[[1]][[1]]
      print('final result')
      print(result)
      insertUI(
        selector = "#scoringResponse",
        where = "beforeEnd",
        ui = panel(
          
          tabsetPanel(type="tabs",
                      tabPanel("Weather Prediction",
                               br(),
                               p('Temperature Degree Farenheit (°F) | Humidity given in percentage (%)', style = "font-size:16px; text-align: center; color: #FA8072"), 
                               p('Precipitation given in inches | WindSpeed given in miles per hour (mph)', style = "font-size:16px; text-align: center; color: #FA8072"),
                               br(),
                               plotlyOutput("probPlot"),
                               ),
                      tabPanel("Temperature vs Humidity", 
                               br(),
                               p('Minimize Evaporation Loss', style = "font-size:20px; text-align: center; color: #2E8B57"),
                               p('Temperature-Humidity relation to determine the lifetime of a droplet on a leaf.', style = "font-size:18px; text-align: center; color: #DC143C"),
                               p('Temperature Range 82 - 86°F', style = "font-size:18px; text-align: center; color: #DC143C"),
                               p('Humidity Range 60 - 70%', style = "font-size:18px; text-align: center; color: #DC143C"),
                               plotlyOutput("comb")),
                      tabPanel("Alert Based on the Crop Guide",plotlyOutput("al")))
          
          
        )
      )
      
      comb <-   plot_ly(data=df_comb, x=df_comb$Temperature, y=df_comb$Humidity,
                hoverinfo = 'text',
                hovertext = ~paste('Temperature: ', df_comb$Temperature,
                                   'Humidity: ',df_comb$Humidity),
                showlegend = FALSE)%>%
        add_trace(y = df_comb$Humidity,
                  type = 'scatter',
                  mode = 'lines+markers+text', 
                  line = list(color = 'rgb(242,142,43)', 
                              width = 3),
                  textposition = "bottom center", # here the text position
                  marker = list(color = 'rgb(242,142,43)', 
                                size = 8)) %>%
        layout(
          title = "Temperature(°F) vs Humidity(%) ",
          yaxis = list(title = "Humidity"),
          xaxis = list(title='Temperature'),
          hoverlabel = list(bgcolor= 'white')
        )
      
       plot_ly(data=df_comb, x=df_comb$Temperature, y=df_comb$Humidity, 
                      type='scatter', mode='lines+marker+text', width=800, 
                      height=400, name = "Temperature", line = list(color = 'rgb(242,142,43)', width = 3),
                      textposition = "bottom center") 
      
      # Alert Graph
      al <- plot_ly(
        type = 'table',
        header = list(
          values = alert_date,
          line = list(color = '#506784'),
          fill = list(color = '#FA8072'),
          align = c('left'),
          font = list(color = '#000000', size = 15),
          height = 30
        ),
        cells = list(
          values = unname(df_alert),
          line = list(color = '#506784'),
          fill = list(color = c('#f4f4f4',
                                'white')),
          align = c('left', 'center'),
          font = list(color = c('#000000'), size = 15),
          height = 30
        ), height=800) 
      
      pred <- plot_ly(
        type = 'table',
        header = list(
          values = c(names(df_pred)),
          line = list(color = '#506784'),
          fill = list(color = '#FA8072'),
          align = c('left'),
          font = list(color = '#000000', size = 17),
          height = 40
        ),
        cells = list(
          values = rbind(t(as.matrix(unname(df_pred)))),
          line = list(color = '#506784'),
          fill = list(color = c('#f4f4f4',
                                'white')),
          align = c('left', 'center'),
          font = list(color = c('#000000'), size = 15),
          height = 40
        ), height=800)  
      
      output$txt <- renderText(r)
      output$probPlot <- renderPlotly(pred)
      output$comb <- renderPlotly(comb)
      output$al <- renderPlotly(al)
      
     
      
    } else {
      output$scoringError <- renderText(response)
    }
    
    shinyjs::enable("scoreBtn")
  })
}
